let myVar = 8;
console.log(typeof myVar);
myVar = "Test";
console.log(typeof myVar);

let nummer = 1; 
let zeichen = '1';
var ergebnis = nummer+zeichen;
console.log(ergebnis + 'has type:' + typeof ergebnis);
