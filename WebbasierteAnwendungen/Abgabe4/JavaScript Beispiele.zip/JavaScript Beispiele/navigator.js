if(navigator.onLine) {
	console.log("Sie sind mit dem Internet verbunden.");
} else {
	console.log("Sie sind nicht mit dem Internet verbunden.");
}

if(navigator.language=='de') {
	console.log("Hallo!");
} else if(navigator.language=='en') {
	console.log("Hello!");
}