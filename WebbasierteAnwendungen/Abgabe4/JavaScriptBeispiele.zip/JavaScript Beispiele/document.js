document.open();
document.write("Ich habe geschrieben!");
document.close();