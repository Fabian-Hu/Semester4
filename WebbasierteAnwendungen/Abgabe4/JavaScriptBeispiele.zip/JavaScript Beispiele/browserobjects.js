//for(var i in navigator) {
//	console.log(i + ' = ' + navigator[i]);
//}

//for(var i in navigator.mediaDevices) {
//	console.log(i + ' = ' + navigator.mediaDevices[i]);
//}

//console.log(navigator.parent);

//for(var i in window) {
//	console.log(i + ' = ' + window[i]);
//}

//console.log(window.parent);

//for(var i in window.applicationCache) {
//	console.log(i + ' = ' + window.applicationCache[i]);
//}

for(var i in window.location) {
	console.log(i + ' = ' + window.location[i]);
}

//for(var i in window.localStorage) {
//	console.log(i + ' = ' + window.localStorage[i]);
//}

//for(var i in window.indexedDB) {
//	console.log(i + ' = ' + window.indexedDB[i]);
//}

//console.log('caches:');
//for(var i in window.sessionStorage) {
//	console.log(i + ' = ' + window.sessionStorage[i]);
//}