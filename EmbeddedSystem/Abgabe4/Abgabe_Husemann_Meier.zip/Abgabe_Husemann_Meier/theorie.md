# Praktikum 4 (10 Punkte) - Energia: Polling und Interrupts 

von Fabian Husemann und Tim Meier

## Aufgabe Pre 1

Die Beschaltung des Tasters ist pull-down, da sich der Switch zwischen den 3,3V, dem digitalen Input und dem Widerstand befindet. 

Die Schaltung ist high active, da sie mit 3,3 V startet und mit 0V ausgeschaltet wird.

## Aufgabe 1

Kurz drücken des Tasters reicht womöglich nicht aus, da der buttonstate nicht permanent abgefragt wird. 
Gedrückt halten des Tasters ist eine bessere Alternative, da der Buttonstate nur beim Wechseln des Lampenstatus ausgelesen wird. 



 die libs sind nicht mit hochgeladen, weil sie zu groß sind.